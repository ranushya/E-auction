package com.auction.controller;

import java.io.IOException;




import java.io.PrintWriter;

import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;


import com.auction.beans.BidProduct;
import com.auction.service.BidService;
import com.auction.service.BidServiceImpl;


@WebServlet("/BidServlet")
public class BidServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	BidService service=new BidServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException,NumberFormatException {
		response.setContentType("text/html");
		int bidPrice=Integer.parseInt(request.getParameter("bidPrice")) ;
		HttpSession ss = request.getSession(); 
		String bidId = (String) ss.getAttribute("username");
		String d1=request.getParameter("date") ;
		BidProduct bp= new BidProduct(bidPrice, bidId, d1);
		bp.setBidPrice(bidPrice); 
		bp.setBidId(bidId);
		PrintWriter pw=response.getWriter();
		List<BidProduct> bps=service.getBidDetails();
		pw.println("<table border=1>");
		pw.println("<tr><th>Eno</th><th>name</th><th>Address</th><th>Gender</th></tr>");
		for(BidProduct e: bps)
		{
			pw.println("<tr><td>"+e.getBidId()+"</td><td>"+e.getBidPrice()+"</td><td>"+e.getDate()+"</td></tr>");
		}
		pw.println("</table>");
		response.sendRedirect("bidding.jsp");
		pw.close();
	}

}
