package com.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.auction.beans.BidProduct;
import com.auction.beans.User;

@WebServlet("/BidServlet")
public class BidServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int BidPrice=Integer.parseInt(request.getParameter("BidPrice")) ;
		String BidId= (String)request.getAttribute("username");
		BidProduct bp= new BidProduct(BidId,BidPrice);
		bp.setBidPrice(BidPrice); 
		bp.setBidId(BidId);
		
	}

}
