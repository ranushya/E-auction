package com.auction.dao;


import com.auction.beans.User;


public interface UserDao {
	public boolean validateUser(User user);
}
