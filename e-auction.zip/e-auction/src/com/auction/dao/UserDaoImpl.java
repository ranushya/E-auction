package com.auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.auction.beans.User;
import com.auction.util.DBConstants;
import com.auction.util.DBUtil;


public class UserDaoImpl implements UserDao {


	@Override
	public boolean validateUser(User user) {
		Connection con=null;
		PreparedStatement pst=null;
		boolean b=false;
		try {
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			pst=con.prepareStatement("select * from login where userid=? and pwd=?");
			pst.setString (1, user.getUserid());
			pst.setString(2, user.getPwd());
			ResultSet rs=pst.executeQuery();
			if(rs.next())
				b=true;
			else
				b=false;
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;
		
	}

	
	

}
