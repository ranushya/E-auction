package com.auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.auction.beans.BidProduct;
import com.auction.util.DBConstants;
import com.auction.util.DBUtil;


public class BidDaoImpl implements BidDao{
	@Override
	public boolean insert(BidProduct bp) {
		Connection con=null;
		PreparedStatement pst=null;
		boolean b=false;
		try {
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			pst=con.prepareStatement("update bid(bid_id=?,bid_price=?,reamining_days=?)");
			pst.setString(1, bp.getBidId());
			pst.setInt(2, bp.getBidPrice() );
			int r=pst.executeUpdate();
		
			if(r>0)
				b=true;
			else
				b=false;
			con.close();
			
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		return b;
	}

	@Override
	public List<BidProduct> getBidDetails() {
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		List<BidProduct> bps=new ArrayList<BidProduct>();
		try {
			con=DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL, DBConstants.UNAME, DBConstants.PWD);
			st=con.createStatement();
			rs=st.executeQuery("select * from bid");
			while(rs.next())
			{
				bps.add(new BidProduct(rs.getString(1), rs.getInt(2)));
			}
			rs.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
			return bps;
	}


}
