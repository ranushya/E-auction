package com.auction.dao;

import java.util.List;

import com.auction.beans.BidProduct;


public interface BidDao {
		public boolean insert(BidProduct bp); 
		public List<BidProduct> getBidDetails();
}
