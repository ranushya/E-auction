package com.auction.dao;

import java.util.List;

import com.auction.beans.BidProduct;


public interface BidDao {
		public boolean Update(BidProduct bp); 
		List<BidProduct> getBidDetails();

		
}
