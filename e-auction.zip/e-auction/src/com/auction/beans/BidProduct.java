package com.auction.beans;

public class BidProduct {
	int BidPrice;
	String BidId;
	public BidProduct( String bidId,int bidPrice) {
		super();
		BidPrice = bidPrice;
		BidId = bidId;
	}

	public int getBidPrice() {
		return BidPrice;
	}
    
	public void setBidPrice(int bidPrice) {
		BidPrice = bidPrice;
	}
	public String getBidId() {
		return BidId;
	}

	public void setBidId(String bidId) {
		BidId = bidId;
	}
	

	
	

}
