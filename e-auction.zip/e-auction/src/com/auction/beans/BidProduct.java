package com.auction.beans;

public class BidProduct {
	int bidPrice;
	String bidId;
	String date;
	/**
	 * @param bidPrice
	 * @param bidId
	 * @param date
	 */
	public BidProduct(int bidPrice, String bidId, String date) {
		super();
		this.bidPrice = bidPrice;
		this.bidId = bidId;
		this.date = date;
	}
	public int getBidPrice() {
		return bidPrice;
	}
	public void setBidPrice(int bidPrice) {
		this.bidPrice = bidPrice;
	}
	public String getBidId() {
		return bidId;
	}
	public void setBidId(String bidId) {
		this.bidId = bidId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}

	

}
