package com.auction.service;

import com.auction.beans.User;
import com.auction.dao.UserDao;
import com.auction.dao.UserDaoImpl;

public class LoginServiceImpl implements LoginService {

	 UserDao dao=new  UserDaoImpl();
	public boolean validateUser(User u)
	{
		boolean res=dao.validateUser(u);
		return res;
	}
}
