package com.auction.service;



import java.util.List;
import com.auction.beans.BidProduct;
import com.auction.dao.BidDao;
import com.auction.dao.BidDaoImpl;

public class BidServiceImpl implements BidService{

	BidDao dao= new BidDaoImpl();
	public boolean Update(BidProduct bp) {
		
		boolean res=dao.Update(bp);
		return res;
	}
	@Override
	public List<BidProduct> getBidDetails() {
		List<BidProduct> bps=dao.getBidDetails();
		return bps;
	}
	

}
