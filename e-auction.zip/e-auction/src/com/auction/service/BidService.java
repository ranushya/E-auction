package com.auction.service;

import java.util.List;


import com.auction.beans.BidProduct;

public interface BidService {
	public boolean Update(BidProduct bp);
	public List<BidProduct> getBidDetails();
}
