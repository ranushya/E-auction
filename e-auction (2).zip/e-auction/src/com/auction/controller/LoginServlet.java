package com.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.auction.beans.User;
import com.auction.dao.UserDao;
import com.auction.dao.UserDaoImpl;
import com.auction.service.LoginService;
import com.auction.service.LoginServiceImpl;


@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String username;
	LoginService service=new LoginServiceImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String userid=request.getParameter("userid");
		String pwd=request.getParameter("pwd");
		User u= new User(userid, pwd);
		u.setUserid(userid);
		u.setPwd(pwd);
		if(service.validateUser(u))
		{
			HttpSession session=request.getSession();
			request.setAttribute("username", u.getUserid());
			RequestDispatcher rd=request.getRequestDispatcher("action.jsp");
			rd.forward(request,response);
		}
		else
		{
			pw.println("<script>alert('Invalid username or password')</script> ");
			RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
			rd.include(request,response);
		}
		
	}
	
	

}
