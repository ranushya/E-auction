package com.auction.service;

import com.auction.beans.User;

public interface LoginService {
	
	public boolean validateUser(User user);

}
